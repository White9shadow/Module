# WiFi2.4GhzDisabler

Disable WiFi 2.4Ghz Band on your Qualcomm device

**NOTICE: On some ROMS with 4.x kernel and Android P (or latest) doesn't work**

# Credit
Based on WiFi5GhzDisabler https://github.com/Magisk-Modules-Repo/wifi5ghzdisabler